/*-
 * #%L
 * AudioPlayer
 * %%
 * Copyright (C) 2016 - 2021 Rémi Cocula
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/gpl-3.0.html>.
 * #L%
 */
package com.github.biconou.newaudioplayer.channels

import com.github.biconou.newaudioplayer.impl.AudioDataMessageType
import com.github.biconou.newaudioplayer.impl.DataMessage
import java.rmi.server.UnicastRemoteObject

class RemoteDataChannelImpl : UnicastRemoteObject(), RemoteDataChannel {

    val localDataChannel = LocalDataChannel()

    override fun push(audioDataMessage: DataMessage) {
        localDataChannel.push(audioDataMessage)
    }

    override fun pull(): DataMessage {
        return localDataChannel.pull()
    }

    override fun purge() {
        localDataChannel.purge()
    }

    override fun begin(audioFormatKey: String) {
        localDataChannel.push(DataMessage(audioFormatKey, null, 0, AudioDataMessageType.BEGIN))
    }

    override fun end(audioFormatKey: String) {
        localDataChannel.push(DataMessage(audioFormatKey, null, 0, AudioDataMessageType.END))
    }
}

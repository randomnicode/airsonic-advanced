/*-
 * #%L
 * AudioPlayer
 * %%
 * Copyright (C) 2016 - 2021 Rémi Cocula
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/gpl-3.0.html>.
 * #L%
 */
package com.github.biconou.newaudioplayer.audio.streams

import java.io.IOException
import javax.sound.sampled.AudioInputStream


val AudioInputStream.bytesPerSecond: Int
    get() = format.sampleRate.toInt() * format.frameSize

@Throws(IOException::class)
// TODO utiliser une paire pour le type retour
fun AudioInputStream.readOneSecond(buffer: ByteArray): Int {
    var bytes: Int
    var totalBytesRead = 0
    val bytesPerSecond = this.bytesPerSecond
    while (totalBytesRead < bytesPerSecond) {
        bytes = this.read(buffer, totalBytesRead, bytesPerSecond - totalBytesRead)
        if (totalBytesRead == 0 && bytes == -1) {
            return -1
        }
        if (bytes != -1) {
            totalBytesRead += bytes
        } else {
            return totalBytesRead
        }
    }
    return totalBytesRead
}

/*-
 * #%L
 * AudioPlayer
 * %%
 * Copyright (C) 2016 - 2021 Rémi Cocula
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/gpl-3.0.html>.
 * #L%
 */
package com.github.biconou.newaudioplayer.channels

import com.github.biconou.newaudioplayer.impl.ControlMessage
import java.rmi.Naming
import java.rmi.registry.LocateRegistry

class RemoteControlChannelAdapter(host: String): ControlChannel{

    var remoteControlChannel: RemoteControlChannel

    init {
        val registry = LocateRegistry.getRegistry(host)
        remoteControlChannel = registry.lookup("controlChannel") as RemoteControlChannel
    }

    override fun push(controlMessage: ControlMessage) {
        remoteControlChannel.push(controlMessage)
    }

    override fun pause() {
        remoteControlChannel.pause()
    }

    override fun play() {
        remoteControlChannel.play()
    }

    override fun pull(): ControlMessage {
        return remoteControlChannel.pull()
    }
}

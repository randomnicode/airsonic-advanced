/*-
 * #%L
 * AudioPlayer
 * %%
 * Copyright (C) 2016 - 2021 Rémi Cocula
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/gpl-3.0.html>.
 * #L%
 */
package com.github.biconou.newaudioplayer

import javax.sound.sampled.AudioFormat


fun AudioFormat.computeFormatKey(): String {
    val sb = StringBuilder()
    sb.append(encoding).append("_")
    sb.append(sampleRate.toLong()).append("_")
    sb.append(sampleSizeInBits).append("_")
    if (isBigEndian) {
        sb.append("BE")
    } else {
        sb.append("LE")
    }
    return sb.toString()
}

object supportedAudioFormats {
    val formats = listOf(
            AudioFormat(
                    AudioFormat.Encoding.PCM_SIGNED,
                    44100.toFloat(),
                    16,
                    2,
                    4,
                    44100.toFloat(),
                    false)
    )

    private val formatsMap = mutableMapOf<String, AudioFormat>()

    init {
        with(formatsMap) {
            formats.forEach { put(it.computeFormatKey(), it) }
        }
    }

    fun findFormat(formatKey: String): AudioFormat? {
        return formatsMap[formatKey]
    }
}

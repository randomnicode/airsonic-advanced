/*-
 * #%L
 * AudioPlayer
 * %%
 * Copyright (C) 2016 - 2021 Rémi Cocula
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/gpl-3.0.html>.
 * #L%
 */
package com.github.biconou.newaudioplayer.channels

import com.github.biconou.newaudioplayer.impl.DataMessage
import java.rmi.registry.LocateRegistry
import javax.sound.sampled.AudioInputStream


class RemoteDataChannelAdapter(host: String) : DataChannel {

    var remoteDataChannel: RemoteDataChannel

    init {
        val registry = LocateRegistry.getRegistry(host)
        remoteDataChannel = registry.lookup("dataChannel") as RemoteDataChannel

    }

    override fun push(audioDataMessage: DataMessage) {
        remoteDataChannel.push(audioDataMessage)
    }

    override fun pull(): DataMessage {
        return remoteDataChannel.pull()
    }

    override fun purge() {
        remoteDataChannel.purge()
    }

    override fun begin(audioFormatKey: String) {
        remoteDataChannel.begin(audioFormatKey)
    }

    override fun end(audioFormatKey: String) {
        remoteDataChannel.end(audioFormatKey)
    }


}

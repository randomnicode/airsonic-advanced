/*-
 * #%L
 * AudioPlayer
 * %%
 * Copyright (C) 2016 - 2021 Rémi Cocula
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/gpl-3.0.html>.
 * #L%
 */
package com.github.biconou.newaudioplayer.impl

import com.github.biconou.newaudioplayer.channels.ControlChannel
import com.github.biconou.newaudioplayer.channels.DataChannel
import com.github.biconou.newaudioplayer.channels.LocalControlChannel
import com.github.biconou.newaudioplayer.channels.LocalDataChannel
import com.github.biconou.newaudioplayer.findMixerByName
import com.github.biconou.newaudioplayer.supportedAudioFormats
import org.slf4j.LoggerFactory
import javax.sound.sampled.AudioFormat
import javax.sound.sampled.DataLine
import javax.sound.sampled.LineUnavailableException
import javax.sound.sampled.SourceDataLine
import kotlin.concurrent.thread

class NewPlayer(playerName: String, dataChannel: DataChannel, controlChannel: ControlChannel) {

    companion object {
        private val log = LoggerFactory.getLogger(NewPlayer.javaClass)
    }

    // TODO ici dans le cas où n'est pas trouvé, ça devrait planter
    private val mixer = findMixerByName(playerName)
    // TODO utiliser lateinit ?
    private var dataLine: SourceDataLine? = null
    private val lock = Object()
    private var mustWait: Boolean = true

    val controlThread = thread(start = true, name = "player_control_thread") {
        while (true) {
            val controlMessage = controlChannel.pull()
            when (controlMessage.type) {
                ControlMessageType.PLAY -> synchronized(lock) {
                    mustWait = false
                    lock.notify()
                }
                ControlMessageType.PAUSE -> synchronized(lock) {
                    mustWait = true
                }
            }
        }
    }

    val dataThread = thread(start = true, name = "player_data_thread") {
        while (true) {
            if (mustWait) {
                synchronized(lock) {
                    lock.wait()
                }
            }
            val dataMessage = dataChannel.pull()
            when (dataMessage.type) {
                AudioDataMessageType.BEGIN -> {
                    val format = supportedAudioFormats.findFormat(dataMessage.audioFormat)
                    if (format != null) {
                        prepareSourceDataLine(format)
                    } else {
                        throw RuntimeException("format $format is not supported")
                    }
                }
                AudioDataMessageType.DATA -> this.dataLine?.write(dataMessage.data, 0, dataMessage.lengthInBytes)
            }
        }
    }

    @Throws(LineUnavailableException::class)
    private fun prepareSourceDataLine(audioFormat: AudioFormat) {
        log.debug("Start new source data line for audio format {}", audioFormat.toString())
        dataLine?.close()
        val info = DataLine.Info(SourceDataLine::class.java, audioFormat)
        dataLine = mixer?.getLine(info) as SourceDataLine
        dataLine?.open(audioFormat)
        dataLine?.start()
    }

}

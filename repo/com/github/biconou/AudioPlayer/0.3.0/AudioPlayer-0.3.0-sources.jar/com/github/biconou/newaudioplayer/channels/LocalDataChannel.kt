/*-
 * #%L
 * AudioPlayer
 * %%
 * Copyright (C) 2016 - 2021 Rémi Cocula
 * %%
 * This program is free software: you can redistribute it and/or modify
 * it under the terms of the GNU General Public License as
 * published by the Free Software Foundation, either version 3 of the
 * License, or (at your option) any later version.
 * 
 * This program is distributed in the hope that it will be useful,
 * but WITHOUT ANY WARRANTY; without even the implied warranty of
 * MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
 * GNU General Public License for more details.
 * 
 * You should have received a copy of the GNU General Public
 * License along with this program.  If not, see
 * <http://www.gnu.org/licenses/gpl-3.0.html>.
 * #L%
 */
package com.github.biconou.newaudioplayer.channels

import com.github.biconou.newaudioplayer.impl.AudioDataMessageType
import com.github.biconou.newaudioplayer.impl.DataMessage
import java.util.concurrent.LinkedBlockingQueue

class LocalDataChannel : DataChannel {

    private val queue = LinkedBlockingQueue<DataMessage>(10)

    override fun push(audioDataMessage: DataMessage) {
        queue.put(audioDataMessage)
    }

    override fun pull(): DataMessage {
        return queue.take()
    }

    override fun purge() {
        queue.clear()
    }

    override fun begin(audioFormatKey: String) {
        push(DataMessage(audioFormatKey, null, 0, AudioDataMessageType.BEGIN))
    }

    override fun end(audioFormatKey: String) {
        push(DataMessage(audioFormatKey, null, 0, AudioDataMessageType.END))
    }
}
